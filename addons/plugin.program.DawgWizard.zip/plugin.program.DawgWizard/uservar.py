'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/jason247g/Dawg/main/wizard_builds.json'

'''#####-----Videos File-----#####'''
videos_url = 'https://raw.githubusercontent.com/jason247g/Dawg/main/videos.txt'

'''#####-----Notification File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/jason247g/Dawg/main/notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'https://raw.githubusercontent.com/jason247g/Dawg/main/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
